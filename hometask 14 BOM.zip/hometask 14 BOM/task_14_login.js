// Створити декілька сторінок ( окремі html файли ):

// login page
// login - я, як юзер, хочу клікнути на цю кнопку та перейти в мій профіль.
// за дпомогою setTimeout через 2 секунди перекините на profile сторінку
// ці 2 секунди повинен крутитись лоадер
// вивести в консоль значення з email + password
// email просто поле для вводу
// password просто поле для вводу
// my-profile page ( optional )
// дістати дані про розмір screen юзера і вивести у консоль
// додати кнопку з текстом back, по кліку на цю кнопку переходимо назад на login сторінку ( не можна використовувати <a> )
// TO BE HERO - взяти поточну локацію юзера і за допомогою google maps api вивести в консоль вашу адресу.

let emailLabel = document.querySelector("#email");
let passwordLabel = document.querySelector("#password");
let form = document.querySelector("#form");
// // let password = [];
// // let email = [];

// let submit = document.querySelector("#submit");
// let loader = document.querySelector(".loader");

form.addEventListener("submit", (event) => {
  let password = [];
  let email = [];
  if (emailLabel.value.length > 6 && passwordLabel.value.length >= 4) {
    console.log(emailLabel.value);
    console.log(passwordLabel.value);
    event.preventDefault();
    setTimeout(() => {
      window.location.href =
        "file:///C:/Users/User/Desktop/HILLEL%20Frontend%20Pro%2014112022/hometask%2014%20BOM/task_14_my-profile.html";
    }, 2000);
  }
  loader.style.display = "flex";
});
