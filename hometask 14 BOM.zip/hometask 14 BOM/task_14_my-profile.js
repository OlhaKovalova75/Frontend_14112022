let back = document.querySelector(".button");
window.addEventListener("click", () => {
  history.back();
  // document.querySelector(".loader").style.display = "block";
  //   window.location.href = "../task_14_login.html";
});
// let backToPage = function () {
//   window.location.href = "./task_14_login.html";
//   return backToPage;
// };
// document.querySelector("button").onclick = back;
