export const showButton = () => console.log("Button component");
