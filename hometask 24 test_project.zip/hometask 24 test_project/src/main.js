import jquery from "jquery";
import { showButton } from "./button/button";
import "./main.css";
import image from "./assets/react-icon.png";
console.log({ jquery });
showButton();

const picture = document.createElement("img");
picture.setAttribute("src", image);
document.body.appendChild(picture);

const wellDone = document.createElement("h1");
wellDone.textContent = "Я зробила це!!!";
document.body.appendChild(wellDone);
